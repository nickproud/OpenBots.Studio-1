#OpenBots-Chrome-Extension

The Chrome Extension used to communicate with the OpenBots Server Host Console Application
