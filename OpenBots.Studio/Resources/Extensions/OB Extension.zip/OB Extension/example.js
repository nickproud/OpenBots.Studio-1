
// (function() {

// alert(1);
// document.getElementsByClassName("gLFyf gsfi")[0].addEventListener("click", myFunction);

// function myFunction() {
  // alert("Clicked");
// }

// })();

document.body.style.background = "red";
